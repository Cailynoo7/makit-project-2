# cell: flower
import math
flower_surface_shift=param("flower_surface_shift",5.0)
flower_radius=param("flower_radius",23.0)
petal_width=param("petal_width",19.0)
petal_height=param("petal_height",30.0)
flower_z=param("flower_z",105.0)
flower_depth=param("flower_depth",2.5)
petal_outline=param("petal_outline",1.5)
flower_center_radius=param("flower_center_radius",10.0)
petal_edge_radius=param("petal_edge_radius",0.6)
flower_outlines_depth=param("flower_outlines_depth",1.2)
flower_outlines_edge_radius=param("flower_outlines_edge_radius",0.5)
flower_center_depth=param("flower_center_depth",1.8)
flower_center_edge_radius=param("flower_center_edge_radius",0.5)
flower_petals_shoulder=param("flower_petals_shoulder",0.12)
host_depth=69.0
def right(s,d):
 return Rot(0,0,90)*Pos(0,-(d+flower_surface_shift),0)*Rot(90,0,0)*s
def petal_profile(width,height):
 # Full rounded outer end, smoothly narrowing into a rounded root.
 shoulder=flower_petals_shoulder
 control=[
  [(0,-.5),(-.14,-.5),(-.5,-.10),(-.5,shoulder)],
  [(-.5,shoulder),(-.5,.37),(-.30,.5),(0,.5)],
  [(0,.5),(.30,.5),(.5,.37),(.5,shoulder)],
  [(.5,shoulder),(.5,-.10),(.14,-.5),(0,-.5)]]
 return Face(Wire([Bezier(*[(x*width,y*height) for x,y in points]) for points in control]))
def rounded(profile,depth,radius):
 blank=extrude(profile,amount=depth,dir=(0,0,1))
 return fillet(blank.edges().group_by(Axis.Z)[-1],radius=radius)
outline_blank=rounded(petal_profile(petal_width+2*petal_outline,petal_height+2*petal_outline),flower_outlines_depth,flower_outlines_edge_radius)
petal_blank=rounded(petal_profile(petal_width,petal_height),flower_depth,petal_edge_radius)
outlines=[]
petals=[]
for a in (90,18,-54,-126,162):
 x=flower_radius*math.cos(math.radians(a))
 z=flower_z+flower_radius*math.sin(math.radians(a))
 pose=Pos(x,z,0)*Rot(0,0,a-90)
 outlines.append(right(pose*outline_blank,host_depth))
 petals.append(right(pose*petal_blank,host_depth+flower_outlines_depth))
pink=Compound(children=outlines)
pink.color=Color(1.0,0.67,0.78)
publish("flower_outlines",pink,"Pink petal outlines",material="pla")
white=Compound(children=petals)
assert len(white.solids())==5 and all(s.is_valid for s in white.solids())
white.color=Color(0.98,0.96,0.97)
publish("flower_petals",white,"Five rounded white petals",material="pla")
core_blank=rounded(Circle(flower_center_radius),flower_center_depth,flower_center_edge_radius)
core=right(Pos(0,flower_z,0)*core_blank,host_depth+flower_outlines_depth+flower_depth)
core.color=Color(1.0,0.72,0.05)
publish("flower_center",core,"Yellow flower centre",material="pla")

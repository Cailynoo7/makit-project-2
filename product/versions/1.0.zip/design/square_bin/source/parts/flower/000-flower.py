# cell: flower
import math
flower_radius=param("flower_radius",23.0)
petal_width=param("petal_width",19.0)
petal_height=param("petal_height",30.0)
flower_z=param("flower_z",105.0)
flower_depth=param("flower_depth",2.5)
petal_outline=param("petal_outline",1.5)
flower_center_radius=param("flower_center_radius",10.0)
petal_edge_radius=param("petal_edge_radius",0.6)
def right(s,d=69):
 return Rot(0,0,90)*Pos(0,-d,0)*Rot(90,0,0)*s
outline_blank=extrude(Ellipse(petal_width/2+petal_outline,petal_height/2+petal_outline),amount=1.2)
outline_blank=fillet(outline_blank.edges().group_by(Axis.Z)[-1],radius=0.4)
petal_blank=extrude(Ellipse(petal_width/2,petal_height/2),amount=flower_depth)
petal_blank=fillet(petal_blank.edges().group_by(Axis.Z)[-1],radius=petal_edge_radius)
outlines=[]
petals=[]
for a in (90,18,-54,-126,162):
 x=flower_radius*math.cos(math.radians(a))
 z=flower_z+flower_radius*math.sin(math.radians(a))
 pose=Pos(x,z,0)*Rot(0,0,a-90)
 outlines.append(right(pose*outline_blank,69))
 petals.append(right(pose*petal_blank,70.2))
pink=Compound(children=outlines)
pink.color=Color(1.0,0.67,0.78)
publish("flower_outlines",pink,"Pink petal outlines",material="pla")
white=Compound(children=petals)
white.color=Color(0.98,0.96,0.97)
publish("flower_petals",white,"Five rounded white petals",material="pla")
core_blank=extrude(Circle(flower_center_radius),amount=1.8)
core_blank=fillet(core_blank.edges().group_by(Axis.Z)[-1],radius=0.5)
core=right(Pos(0,flower_z,0)*core_blank,72.7)
core.color=Color(1.0,0.72,0.05)
publish("flower_center",core,"Yellow flower centre",material="pla")
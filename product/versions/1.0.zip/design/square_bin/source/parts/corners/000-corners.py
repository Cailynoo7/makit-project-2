# cell: corners
corner_offset=param("corner_offset",68.0)
corner_width=param("corner_width",14.0)
corner_lower_height=param("corner_lower_height",22.0)
corner_upper_z=param("corner_upper_z",148.0)
corner_upper_height=param("corner_upper_height",20.0)
corner_plan_radius=param("corner_plan_radius",4.0)
corner_edge_radius=param("corner_edge_radius",1.5)
cap_profile=RectangleRounded(corner_width,corner_width,corner_plan_radius)
lower_blank=extrude(cap_profile,amount=corner_lower_height)
lower_blank=fillet(lower_blank.edges().group_by(Axis.Z)[-1],radius=corner_edge_radius)
upper_blank=extrude(cap_profile,amount=corner_upper_height)
upper_blank=fillet(upper_blank.edges().group_by(Axis.Z)[0],radius=corner_edge_radius)
corner_host_width=param("corner_host_width",138.0)
corner_host_radius=param("corner_host_radius",11.0)
host_envelope=extrude(RectangleRounded(corner_host_width,corner_host_width,corner_host_radius),amount=180)
caps=[]
for x in (-corner_offset,corner_offset):
 for y in (-corner_offset,corner_offset):
  caps.append((Pos(x,y,0)*lower_blank)-host_envelope)
  caps.append((Pos(x,y,corner_upper_z)*upper_blank)-host_envelope)
pink=Compound(children=caps)
pink.color=Color(1.0,0.52,0.69)
publish("pink_corners",pink,"Rounded pink corner guards",material="pla")
# cell: star
import math
star_outer_radius=param("star_outer_radius",32.0)
star_inner_radius=param("star_inner_radius",18.0)
star_center_z=param("star_center_z",104.0)
star_depth=param("star_depth",3.0)
star_corner_radius=param("star_corner_radius",1.6)
star_outline_width=param("star_outline_width",1.7)
star_eye_radius=param("star_eye_radius",3.2)
def left(s,d=69):
 return Rot(0,0,270)*Pos(0,-d,0)*Rot(90,0,0)*s
def star_sketch(ro,ri):
 pts=[]
 for i in range(10):
  a=math.radians(90+i*36)
  rr=ro if i%2==0 else ri
  pts.append((rr*math.cos(a),rr*math.sin(a)))
 shape=Polygon(*pts)
 return fillet(shape.vertices(),radius=star_corner_radius)
outline_blank=extrude(star_sketch(star_outer_radius+star_outline_width,star_inner_radius+star_outline_width),amount=0.8,dir=(0,0,1))
outline=left(Pos(0,star_center_z,0)*outline_blank,69)
outline.color=Color(1.0,0.52,0.05)
publish("star_outline",outline,"Rounded orange star border",material="pla")
body_blank=extrude(star_sketch(star_outer_radius,star_inner_radius),amount=star_depth,dir=(0,0,1))
body_blank=fillet(body_blank.edges().group_by(Axis.Z)[-1],radius=0.6)
star_body=left(Pos(0,star_center_z,0)*body_blank,69.8)
star_body.color=Color(1.0,0.75,0.06)
publish("star_body",star_body,"Rounded yellow star",material="pla")
eyes=[]
for x in (-10,10):
 eyes.append(left(Pos(x,105,0)*extrude(Circle(star_eye_radius),amount=1.2),72.8))
smile_profile=Pos(0,94,0)*(Ellipse(7,3.6)-Pos(0,2,0)*Ellipse(6.5,3.5))
eyes.append(left(extrude(smile_profile,amount=1.2),72.8))
dark=Compound(children=eyes)
dark.color=Color(0.28,0.13,0.10)
publish("star_face",dark,"Star eyes and smile",material="pla")
blue_dots=[]
for x,z,r in [(-43,117,1.9),(-46,94,1.8),(43,119,1.9)]:
 blue_dots.append(left(Pos(x,z,0)*extrude(Circle(r),amount=1.4),69))
blue=Compound(children=blue_dots)
blue.color=Color(0.10,0.62,0.88)
publish("star_sprinkles",blue,"Blue confetti",material="pla")
pink_dots=[]
for x,z,r in [(-46,108,1.7),(-43,81,1.8),(46,108,1.7)]:
 pink_dots.append(left(Pos(x,z,0)*extrude(Circle(r),amount=1.4),69))
pink=Compound(children=pink_dots)
pink.color=Color(1.0,0.43,0.66)
publish("star_pink_confetti",pink,"Pink confetti",material="pla")
green=left(Pos(46,95,0)*extrude(Circle(1.9),amount=1.4),69)
green.color=Color(0.38,0.76,0.22)
publish("star_green_confetti",green,"Green confetti",material="pla")
gold=left(Pos(44,81,0)*extrude(Circle(1.9),amount=1.4),69)
gold.color=Color(1.0,0.69,0.05)
publish("star_gold_confetti",gold,"Gold confetti",material="pla")
# cell: smile_face
import math
face_width=param("face_width",84.0)
face_height=param("face_height",74.0)
face_center_z=param("face_center_z",105.0)
face_relief=param("face_relief",2.4)
face_panel_relief=param("face_panel_relief",2.0)
face_edge_radius=param("face_edge_radius",0.8)
eye_spacing=param("eye_spacing",44.0)
face_eye_z=param("face_eye_z",99.0)
cheek_radius=param("cheek_radius",5.2)
def on_front(shape, depth):
 return Pos(0,-depth,0)*Rot(90,0,0)*shape
border_blank=extrude(RectangleRounded(face_width,face_height,10),amount=face_relief)
border_blank=fillet(border_blank.edges().group_by(Axis.Z)[-1],radius=face_edge_radius)
border=on_front(Pos(0,face_center_z,0)*border_blank,69.0)
border.color=Color(1.0,0.64,0.02)
publish("face_border",border,"Rounded gold plaque rim",material="pla")
panel_blank=extrude(RectangleRounded(face_width-5,face_height-5,8),amount=face_panel_relief)
panel_blank=fillet(panel_blank.edges().group_by(Axis.Z)[-1],radius=face_edge_radius)
panel=on_front(Pos(0,face_center_z,0)*panel_blank,69.0+face_relief)
panel.color=Color(1.0,0.76,0.17)
publish("face_panel",panel,"Soft yellow face plaque",material="pla")
heart_pts=[]
for i in range(64):
 t=2*math.pi*i/64
 heart_pts.append((9.5*math.sin(t)**3,0.56*(13*math.cos(t)-5*math.cos(2*t)-2*math.cos(3*t)-math.cos(4*t))))
features=[]
for x in (-eye_spacing/2,eye_spacing/2):
 features.append(on_front(Pos(x,face_eye_z,0)*extrude(Polygon(*heart_pts),amount=1.4,dir=(0,0,1)),73.4))
smile_profile=Pos(0,86.5,0)*(Ellipse(8.3,4.2)-Pos(0,2.5,0)*Ellipse(7.7,4.0))
features.append(on_front(extrude(smile_profile,amount=1.3),73.4))
dark=Compound(children=features)
dark.color=Color(0.31,0.11,0.09)
publish("face_features",dark,"Smooth heart eyes and smile",material="pla")
cheeks=[]
for x in (-29.5,29.5):
 cheeks.append(on_front(Pos(x,86.5,0)*extrude(Circle(cheek_radius),amount=1.3),73.4))
pink=Compound(children=cheeks)
pink.color=Color(1.0,0.46,0.64)
publish("face_cheeks",pink,"Round pink cheeks",material="pla")
left_pin=on_front(Pos(-30,128.5,0)*extrude(Circle(4.4),amount=1.4),73.4)
left_pin.color=Color(0.03,0.65,0.83)
publish("face_blue_pin",left_pin,"Blue plaque pin",material="pla")
right_pin=on_front(Pos(30,128.5,0)*extrude(Circle(4.4),amount=1.4),73.4)
right_pin.color=Color(1.0,0.42,0.02)
publish("face_orange_pin",right_pin,"Orange plaque pin",material="pla")
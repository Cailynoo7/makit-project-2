# cell: base
# cell: base
base_width=param("base_width",146.0)
base_height=param("base_height",35.0)
base_opening=param("base_opening",138.0)
base_corner_radius=param("base_corner_radius",12.0)
base_outward_growth=param("base_outward_growth",1.0)
base_width=base_width+2*base_outward_growth
base_corner_radius=base_corner_radius+base_outward_growth
outer_profile=RectangleRounded(base_width,base_width,base_corner_radius)
inner_profile=RectangleRounded(base_opening,base_opening,base_corner_radius-(base_width-base_opening)/2)
base=extrude(outer_profile-inner_profile,amount=base_height)
base.color=Color(0.62,0.35,0.20)
publish("brown_base",base,"Brown brick cladding",material="pla")
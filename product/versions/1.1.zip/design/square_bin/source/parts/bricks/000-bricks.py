# cell: bricks
# cell: bricks
brick_relief=param("brick_relief",2.0)
brick_height=param("brick_height",10.5)
brick_width=param("brick_width",28.0)
brick_lower_width=param("brick_lower_width",25.0)
brick_end_width=param("brick_end_width",15.0)
brick_row_spacing=param("brick_row_spacing",11.5)
brick_base_z=param("brick_base_z",11.0)
brick_corner_radius=param("brick_corner_radius",2.0)
brick_edge_radius=param("brick_edge_radius",0.6)
brick_face_depth=param("brick_face_depth",79.0)
def face(s,rotation):
 return Rot(0,0,rotation)*Pos(0,-brick_face_depth,0)*Rot(90,0,0)*s
def brick_blank(width):
 blank=extrude(RectangleRounded(width,brick_height,brick_corner_radius),amount=brick_relief)
 return fillet(blank.edges().group_by(Axis.Z)[-1],radius=brick_edge_radius)
top_blank=brick_blank(brick_width)
lower_blank=brick_blank(brick_lower_width)
end_blank=brick_blank(brick_end_width)
blocks=[]
for rotation in (0,90,180,270):
 for x in (-53,53):
  blocks.append(face(Pos(x,brick_base_z,0)*end_blank,rotation))
 for x in (-27,0,27):
  blocks.append(face(Pos(x,brick_base_z,0)*lower_blank,rotation))
 for x in (-45,-15,15,45):
  blocks.append(face(Pos(x,brick_base_z+brick_row_spacing,0)*top_blank,rotation))
tiles=Compound(children=blocks)
tiles.color=Color(0.72,0.47,0.29)
publish("brick_tiles",tiles,"Rounded staggered bricks",material="pla")
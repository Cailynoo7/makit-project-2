# cell: trim
# cell: trim
trim_outer=param("trim_outer",150.0)
trim_inner=param("trim_inner",138.0)
trim_z=param("trim_z",35.0)
trim_height=param("trim_height",8.0)
scallop_radius=param("scallop_radius",8.0)
scallop_pitch=param("scallop_pitch",16.0)
trim_edge_radius=param("trim_edge_radius",0.8)
band_profile=RectangleRounded(trim_outer,trim_outer,24)-RectangleRounded(trim_inner,trim_inner,18)
band=Pos(0,0,trim_z)*extrude(band_profile,amount=trim_height)
band=fillet(band.edges().group_by(Axis.Z)[-1],radius=trim_edge_radius)
green=band
wave_limit=Pos(0,0,trim_z+trim_height-50)*Box(200,200,100)
for face in range(4):
 for i in range(-4,5):
  u=i*scallop_pitch
  disk=Pos(u,-(trim_outer/2-2),trim_z+2.5)*Rot(90,0,0)*Cylinder(scallop_radius,2.0,align=(Align.CENTER,Align.CENTER,Align.MIN))
  disk=disk & wave_limit
  green=green + Rot(0,0,face*90)*disk
green.color=Color(0.29,0.69,0.25)
publish("green_trim",green,"Rounded nine-wave trim",material="pla")
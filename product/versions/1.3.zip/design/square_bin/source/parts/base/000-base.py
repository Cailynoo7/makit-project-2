import math
# cell: base
# cell: base
base_width=param("base_width",146.0)
base_height=param("base_height",35.0)
base_opening=param("base_opening",138.0)
base_corner_radius=param("base_corner_radius",12.0)
base_outward_growth=param("base_outward_growth",1.0)
base_width=base_width+2*base_outward_growth
base_corner_radius=base_corner_radius+base_outward_growth
outer_profile=RectangleRounded(base_width,base_width,base_corner_radius)
inner_profile=RectangleRounded(base_opening,base_opening,base_corner_radius-(base_width-base_opening)/2)
base=extrude(outer_profile-inner_profile,amount=base_height)
# Three brick courses are carved into one continuous cladding ring.
base_brick_rows=param("base_brick_rows",3)
base_brick_pitch=param("base_brick_pitch",28.0)
base_joint_width=param("base_joint_width",1.2)
base_joint_depth=param("base_joint_depth",0.8)
base_joint_edge_radius=param("base_joint_edge_radius",0.25)
assert int(base_brick_rows)==base_brick_rows and base_brick_rows>=1
row_height=base_height/base_brick_rows
groove_inner=RectangleRounded(base_width-2*base_joint_depth,base_width-2*base_joint_depth,base_corner_radius-base_joint_depth)
joint_band=outer_profile-groove_inner
for i in range(1,int(base_brick_rows)):
 base=base-(Pos(0,0,i*row_height-base_joint_width/2)*extrude(joint_band,amount=base_joint_width))
corner_center=base_width/2-base_corner_radius
for row in range(int(base_brick_rows)):
 z0=row*row_height
 phase=base_brick_pitch/2 if row%2==0 else 0
 for n in range(-3,4):
  x=n*base_brick_pitch+phase
  if abs(x)+base_joint_width/2>=corner_center:
   continue
  for rotation in (0,90,180,270):
   cutter=Rot(0,0,rotation)*Pos(x,-base_width/2+base_joint_depth/2-0.01,z0+row_height/2)*Box(base_joint_width,base_joint_depth+0.02,row_height+base_joint_width)
   base=base-cutter
# Roll only the exposed groove mouths, preserving the inner wall and base envelope.
mouth=[]
for e in base.edges():
 c=e.center()
 r=math.hypot(max(abs(c.X)-corner_center,0),max(abs(c.Y)-corner_center,0))
 if abs(r-base_corner_radius)<0.001 and 0.001<c.Z<base_height-0.001:
  if e.geom_type==GeomType.CIRCLE or (e.geom_type==GeomType.LINE and (abs(c.X)<corner_center-0.01 or abs(c.Y)<corner_center-0.01)):
   mouth.append(e)
base=fillet(mouth,radius=base_joint_edge_radius)
assert len(base.solids())==1, "Brick cladding must remain one solid"
base.color=Color(0.62,0.35,0.20)
publish("brown_base",base,"Brown brick cladding",material="pla")
mushroom_surface_shift=param("mushroom_surface_shift",4.0)
# cell: mushroom
import math
mushroom_width=param("mushroom_width",70.0)
mushroom_center_z=param("mushroom_center_z",109.0)
mushroom_depth=param("mushroom_depth",3.0)
mushroom_edge_radius=param("mushroom_edge_radius",0.8)
mushroom_outline=param("mushroom_outline",2.0)
mushroom_stem_width=param("mushroom_stem_width",27.0)
mushroom_star_radius=param("mushroom_star_radius",7.0)
def back(s,d=69):
 return Rot(0,0,180)*Pos(0,-(d+mushroom_surface_shift),0)*Rot(90,0,0)*s
stem_border_blank=extrude(RectangleRounded(mushroom_stem_width+2*mushroom_outline,36,10),amount=1.0)
stem_border=back(Pos(0,84,0)*stem_border_blank,69)
stem_border.color=Color(1.0,0.54,0.71)
publish("mushroom_stem_border",stem_border,"Pink stem outline",material="pla")
stem_blank=extrude(RectangleRounded(mushroom_stem_width,33,9),amount=2.4)
stem_blank=fillet(stem_blank.edges().group_by(Axis.Z)[-1],radius=0.6)
stem=back(Pos(0,84,0)*stem_blank,70)
stem.color=Color(1.0,0.68,0.18)
publish("mushroom_stem",stem,"Rounded yellow stem",material="pla")
cap_pts=[]
for i in range(25):
 theta=math.pi-math.pi*i/24
 cap_pts.append((mushroom_width/2*math.cos(theta),-1+23*math.sin(theta)))
cap_pts.extend([(32,-12),(24,-16),(0,-17),(-24,-16),(-32,-12)])
outline_pts=[(x*(1+mushroom_outline/35),y*(1+mushroom_outline/20)) for x,y in cap_pts]
cap_outline=back(Pos(0,mushroom_center_z,0)*extrude(Polygon(*outline_pts),amount=1.0,dir=(0,0,1)),69)
cap_outline.color=Color(1.0,0.48,0.68)
publish("mushroom_cap_outline",cap_outline,"Pink cap outline",material="pla")
cap_blank=extrude(Polygon(*cap_pts),amount=mushroom_depth,dir=(0,0,1))
cap_blank=fillet(cap_blank.edges().group_by(Axis.Z)[-1],radius=mushroom_edge_radius)
cap=back(Pos(0,mushroom_center_z,0)*cap_blank,70)
cap.color=Color(0.96,0.20,0.25)
publish("mushroom_cap",cap,"Rounded red mushroom cap",material="pla")
gill_blank=extrude(Ellipse(33,5.0),amount=1.2)
gill=back(Pos(0,92,0)*gill_blank,72.5)
gill.color=Color(0.98,0.95,0.83)
publish("mushroom_gill",gill,"Cream mushroom underside",material="pla")
spots=[]
for x,z,rx,rz in [(-23,108,4.5,7.5),(0,118,10,10),(23,108,4.5,7.5)]:
 spots.append(back(Pos(x,z,0)*extrude(Ellipse(rx,rz),amount=1.2),73))
white_spots=Compound(children=spots)
white_spots.color=Color(1,1,1)
publish("mushroom_spots",white_spots,"White cap spots",material="pla")
star_pts=[]
for i in range(10):
 a=math.pi/2+math.pi*i/5
 rr=mushroom_star_radius if i%2==0 else mushroom_star_radius*0.48
 star_pts.append((rr*math.cos(a),rr*math.sin(a)))
twinkles=[]
for x,z in [(-44,126),(43,126)]:
 twinkles.append(back(Pos(x,z,0)*extrude(Polygon(*star_pts),amount=1.5,dir=(0,0,1)),69))
gold=Compound(children=twinkles)
gold.color=Color(1.0,0.72,0.02)
publish("mushroom_stars",gold,"Two five-point stars",material="pla")
blue_dots=[]
for x,z,r in [(-43,79,2.4),(-32,75,1.4),(0,139,1.2)]:
 blue_dots.append(back(Pos(x,z,0)*extrude(Circle(r),amount=1.5),69))
blue=Compound(children=blue_dots)
blue.color=Color(0.04,0.65,0.88)
publish("mushroom_blue_dots",blue,"Blue confetti",material="pla")
orange=back(Pos(44,78,0)*extrude(Circle(2.3),amount=1.5),69)
orange.color=Color(1.0,0.57,0.04)
publish("mushroom_orange_dot",orange,"Orange confetti",material="pla")